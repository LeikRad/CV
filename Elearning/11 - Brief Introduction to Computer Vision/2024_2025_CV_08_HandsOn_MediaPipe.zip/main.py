import MediaPipeWrapper as mpw
import random
from panda3d.core import loadPrcFile
from panda3d.core import *
from panda3d.core import Filename
loadPrcFile("config/config.prc")
from direct.showbase.ShowBase import ShowBase
from panda3d.core import CardMaker, Texture

from direct.task import Task
import os, sys

#from direct.gui.OnscreenImage import OnscreenImage

#os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'


class MyGame(ShowBase):

    def __init__(self):
        ShowBase.__init__(self)

        self.cameraRadius = 30.0
        self.cameraSpinDirection = 'Left'
        self.cameraAngle = 0

        # Get the location of the 'py' file I'm running:
        self.mydir = os.path.abspath(sys.path[0])
        # convert to panda's specific notation
        self.mydir = Filename.fromOsSpecific(self.mydir).getFullpath()

        # This is the object where everything about processing the camera is wrapped
        self.cap = mpw.CameraProcessor().start()
        self.cap.showFeed(True)

        self.cameraRefresh = 45
        self.cameraRefreshLastTime = 0

        self.disableMouse()
        #

        #self.setUpScene()
        #self.setUpLights()

        self.setUpCamera()
        self.setUpTasks()

        self.minX = -8
        self.maxX = 8
        self.minY = -9
        self.maxY = 6
        self.minZ = 2
        self.maxZ = 4


    def setUpScene(self):

        cm = CardMaker('card')
        card = self.render.attachNewNode(cm.generate())
        card.setScale(46,1,29)
        card.setPos(-23,15,-13)

        self.tex = Texture()
        self.tex.setup2dTexture(640, 480, Texture.T_unsigned_byte, Texture.F_luminance)

        # now apply it to the card

        tex = self.loader.loadTexture(self.mydir + '/space3.png')
        card.setTexture(tex)

        cm = CardMaker('alien')

        self.alienCard = self.render.attachNewNode(cm.generate())

        tex = self.loader.loadTexture(self.mydir + '/alien.png')
        self.alienCard.setTexture(tex)








        self.pandaModel = self.loader.loadModel("models/panda")
        self.pandaModel.setPos(0, -3, 0)
        self.pandaModel.setP(45)
        self.pandaModel.setH(180)
        self.pandaModel.setScale(.3,.3,.3)
        self.pandaModel.reparentTo(self.render)

    def setUpLights(self):
    #
        # adding a white point light
        self.plight2 = PointLight('plight')
        self.plight2.setColor((1, 1, 1, 1))
        self.plnp2 = self.render.attachNewNode(self.plight2)
        self.plnp2.setPos(0, -10, 10)
        self.render.setLight(self.plnp2)
    #
        # adding ambient light for all
        self.alight = AmbientLight('alight')
        self.alight.setColor((0.3, 0.3, 0.3, 1))
        self.alnp = self.render.attachNewNode(self.alight)
        self.render.setLight(self.alnp)
    #
        # crazy ambient light JUST for Panda
        self.alightPanda = AmbientLight('alight')
        self.alightPanda.setColor((1,0, 0, 1))
        # self.pandaModel.setLightOff()
        self.alnpPanda = self.render.attachNewNode(self.alightPanda)
        self.pandaModel.setLight(self.alnpPanda)

    def setUpCamera(self):
         self.camera.setPos(0, -30, 0)

    def setUpTasks(self):
        #self.taskMgr.add(self.spinCameraTask, "SpinCameraTask")
        self.taskMgr.add(self.moveTask, "moveTask")
        #self.taskMgr.add(self.OpenCVTask, "cvTask")


    def closeAll(self):
        self.cap.__del__()
        exit(0)


    def moveTask(self, task):
        isDown = base.mouseWatcherNode.isButtonDown

        if isDown(KeyboardButton.asciiKey("+")):
            self.cameraRadius += 1
        if isDown(KeyboardButton.asciiKey("-")):
            self.cameraRadius -= 1

        if isDown(KeyboardButton.asciiKey("x")):
            self.closeAll()

        return Task.cont


    def spinCameraTask(self, task):
        """ Spin the camera around the center of the scene (0,0,0)"""
        # if self.cameraSpinDirection == 'Left':
        #     spinSpeed = 0
        # elif self.cameraSpinDirection == 'Right':
        #     spinSpeed = -0
        # else:
        #     spinSpeed = 0
        #
        # self.cameraAngle += spinSpeed
        # angleRadians = self.cameraAngle * (math.pi / 180.0)
        #
        # self.camera.setPos(self.cameraRadius * math.sin(angleRadians), -self.cameraRadius * math.cos(angleRadians), 0)
        #
        # # keep the camera looking at the center of the scene
        # self.camera.lookAt(0.0, 0.0, 0.0)
        return Task.cont

    def OpenCVTask(self, task):


        # this is just a workaround to prevent from making computations every possible frame
        # if task.time - self.cameraRefreshLastTime < 1.0/self.cameraRefresh:
        #     return Task.cont
        # self.cameraRefreshLastTime = task.time


        # TV
        # texture = self.cap.capture.image
        #
        # buf = texture[:, :, 0].tostring()  # slice RGB to gray scale, transpose 90 degree, convert to text buffer
        # self.tex.setRamImage(buf)  # overwriting the memory with new buffer
        # self.alienCard.setTexture(self.tex)


        if self.cap.results_hands != None and self.cap.results_hands.multi_hand_landmarks:

            #####################################
            # The left hand is visible
            if self.cap.handMeasures['Left'].visible:
                customScale = self.cap.handMeasures['Right'].dist_thumb_pointer * 1.2
                # do something with this value, here

            #####################################
            # The right hand is visible
            # if the Right hand is visible, use the wrist position to set the panda«s position
            # use the distance between thumb and pointer to move in the yy' direction
            if self.cap.handMeasures['Right'].visible:
                self.pandaModel.setPos((self.cap.handMeasures['Right'].hand.landmark[0].x - 0.5) * (25 + 5*(1 - self.cap.handMeasures['Right'].dist_thumb_pointer)),
                                        10 - self.cap.handMeasures['Right'].dist_thumb_pointer * 65,
                                       (self.cap.handMeasures['Right'].hand.landmark[0].y - 0.5) * -(25 + 5*(1 - self.cap.handMeasures['Right'].dist_thumb_pointer)))

            #####################################
            # Both hands are visible
            if self.cap.handMeasures['Right'].visible and self.cap.handMeasures['Left'].visible:

                # computing distance between the two pointer fingers
                dist_pointers = self.cap.euclidian(self.cap.handMeasures['Right'].hand.landmark[8],
                                                   self.cap.handMeasures['Left'].hand.landmark[8])





        # simple test of colision between panda and alien card
        dist = self.cap.euclidian(self.pandaModel.getPos(), self.alienCard.getPos())
        if (dist < 1.5):
            self.alienCard.setPos(random.uniform(self.minX, self.maxX),
                                  random.uniform(self.minY, self.maxY),
                                  random.uniform(self.minZ, self.maxZ))

        return Task.cont




# https://google.github.io/mediapipe/getting_started/python

game = MyGame()
game.run()

# cap = mpw.CameraProcessor()
# cap.showFeed(True)
# cap.showLandmarks(True)
# cap.start()
