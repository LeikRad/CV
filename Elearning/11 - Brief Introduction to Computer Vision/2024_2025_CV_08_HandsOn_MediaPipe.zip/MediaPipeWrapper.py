import mediapipe as mp
import numpy as np
import cv2
from threading import Thread
import math
import time
from dataclasses import dataclass
from dataclasses import field

class MediaPipeWrapper:
    """ This class wraps some of the functionality of media pipe in convenient methods with all the configurations set.
    """
    def __init__(self):
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_drawing_styles = mp.solutions.drawing_styles
        self.mp_face_mesh = mp.solutions.face_mesh
        self.mp_hands = mp.solutions.hands
        self.mp_objectron = mp.solutions.objectron
        self.mp_selfie_segmentation = mp.solutions.selfie_segmentation
        self.mp_holistic = mp.solutions.holistic

        self._resultsHolistic = None
        self._resultsSelfie = None
        self._resultsFace = None
        self._resultsObjects = None
        self._resultsHands = None

        self.drawing_spec = self.mp_drawing.DrawingSpec(thickness=1, circle_radius=1)

        self.results_hands = None
        self.image = None

        self.bg_image = None

    def detectHolistic(self, image):
        with self.mp_holistic.Holistic(
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5) as holistic:
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            self._resultsHolistic = holistic.process(image)

        return self._resultsHolistic

    def detectSelfie(self, image):

        with self.mp_selfie_segmentation.SelfieSegmentation(
                model_selection=1) as selfie_segmentation:
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            self._resultsSelfie = selfie_segmentation.process(image)

        return self._resultsSelfie

    def drawSelfie(self, image, resultsSelfie):
        BG_COLOR = (192, 192, 192)  # gray

        segmentationMask = np.stack(
            (resultsSelfie.segmentation_mask,) * 3, axis=-1)

       # betterMask = image.copy()
        #betterMask = cv2.ximgproc.jointBilateralFilter(image, segmentationMask.astype('uint8'), d=-1, sigmaColor=10, sigmaSpace=2)

        condition = np.stack(
             (resultsSelfie.segmentation_mask,) * 3, axis=-1) > 0.1



        #bg_image = cv2.GaussianBlur(image, (65, 65), 0)



        if self.bg_image is None:
             bg_image = np.zeros(image.shape, dtype=np.uint8)
             bg_image[:] = BG_COLOR

        final_image = np.where(condition, image, bg_image)

        return final_image


    def detectFaceMesh(self, image):
        with self.mp_face_mesh.FaceMesh(
                max_num_faces=1,
                refine_landmarks=True,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5) as face_mesh:
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            self._resultsFace = face_mesh.process(image)
        return self._resultsFace

    def drawFaceMesh(self, image, resultsFace):
        if resultsFace.multi_face_landmarks:
            for face_landmarks in resultsFace.multi_face_landmarks:
                self.mp_drawing.draw_landmarks(
                    image=image,
                    landmark_list=face_landmarks,
                    connections=self.mp_face_mesh.FACEMESH_TESSELATION,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=self.mp_drawing_styles
                        .get_default_face_mesh_tesselation_style())
                self.mp_drawing.draw_landmarks(
                    image=image,
                    landmark_list=face_landmarks,
                    connections=self.mp_face_mesh.FACEMESH_CONTOURS,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=self.mp_drawing_styles
                        .get_default_face_mesh_contours_style())
                self.mp_drawing.draw_landmarks(
                    image=image,
                    landmark_list=face_landmarks,
                    connections=self.mp_face_mesh.FACEMESH_IRISES,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=self.mp_drawing_styles
                        .get_default_face_mesh_iris_connections_style())

    def drawHands(self, image, resultsHands):
        
        #new_image = image.copy()
        
        if resultsHands != None and resultsHands.multi_hand_landmarks:
            for hand_landmarks in resultsHands.multi_hand_landmarks:
                self.mp_drawing.draw_landmarks(
                    image,
                    hand_landmarks,
                    self.mp_hands.HAND_CONNECTIONS,
                    self.mp_drawing_styles.get_default_hand_landmarks_style(),
                    self.mp_drawing_styles.get_default_hand_connections_style())
          ##  image = new_image
    def reportHands(self, resultsHands):
        if resultsHands.multi_handedness:
            for hand in resultsHands.multi_handedness:
                print(hand)

    def detectHands(self, image):
        self.image = image
        with self.mp_hands.Hands(
                model_complexity=1,
                min_detection_confidence=0.7,
                min_tracking_confidence=0.5) as hands:
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            self._resultsHands = hands.process(image)

        return self._resultsHands

    def detectObjects(self, image):
        """ Just run the object detector for a particular type of object. Initially, cups. Only a few objects are
        supported by the model available in media pipe """
        with self.mp_objectron.Objectron(static_image_mode=False,
                               max_num_objects=5,
                               min_detection_confidence=0.5,
                               min_tracking_confidence=0.99,
                               model_name='Cup') as objectron:

            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            self._resultsObjects = objectron.process(image)

        return self._resultsObjects

    def drawObjects(self, image, resultsObjects):
        if resultsObjects.detected_objects:
            for detected_object in resultsObjects.detected_objects:
                self.mp_drawing.draw_landmarks(
                    image, detected_object.landmarks_2d, self.mp_objectron.BOX_CONNECTIONS)
                self.mp_drawing.draw_axis(image, detected_object.rotation,
                                     detected_object.translation)

    def reportObjects(self, resultsObjects):
        if resultsObjects.detected_objects:
            for object in resultsObjects.detected_objects:
                print(object)

###############################################################################
###############################################################################
###############################################################################
class VideoCaptureThreaded:
    """ This class initiates a thread to capture images from the web camera """
    def __init__(self):
        self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        #self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)

        #self.mediaPipeEngine = mpw.MediaPipeWrapper()

        self.stopped = True

        self.resultsHands = None
        self.resultsFace = None

        self.image = None
        self.imageTmp = None

        self.success = False

        if self.cap.isOpened():
            self.success, self.image = self.cap.read()
            self.image = cv2.flip(self.image, 1)


    def start(self):
        if self.stopped:
            self.stopped = False
            Thread(target=self.get, args=()).start()
        return self

    def get(self):
        while not self.stopped:
            if not self.success:
                self.stop()
            else:
                if self.cap.isOpened():
                    self.success, self.imageTmp = self.cap.read()
                    self.image = cv2.flip(self.imageTmp, 1)
                    self.image.flags.writeable = True
                    #time.sleep(0.05)
                else:
                    self.stop()
        self.stop()

    def stop(self):
        self.stopped = True
        self.cap.release()

###############################################################################
###############################################################################
###############################################################################
class VideoShowerThreaded:
    """ class that initiates a thread for a window showing the contents of the video capture thread """
    def __init__(self, videocapture: VideoCaptureThreaded, mediapipe: MediaPipeWrapper):
        self.stopped = True
        self.image = None
        self.videocapture = videocapture
        self.mediapipe = mediapipe

        self.showLandMarks = True

    def start(self):
        if self.stopped:
            self.stopped = False
            Thread(target=self.show, args=()).start()

        return self

    def show(self):
        while not self.stopped or not self.videocapture.stopped:
            self.image = self.videocapture.image

            if  self.showLandMarks:

                self.image.flags.writeable = True
                self.mediapipe.drawHands(self.image, self.mediapipe._resultsHands) # Todo: solve issue of protected member, later

            if self.image.size:
                cv2.imshow('Webcam Stream', self.image)
                if cv2.waitKey(5) & 0xFF == 27:
                    break
        self.stop()


    def stop(self):
        self.stopped = True

#####################################################
#####################################################
class CameraProcessor:
    """ High level class to get recognized structures from a camera feed. It initiates thread for camera capture,
    camera feed presentation and mediapipe computations """
    @dataclass
    class HandMeasures:
        hand: list = field(default_factory=list)
        visible: bool = False
        dist_thumb_pointer: float = 0.0
        dist_thumb_basepointer: float = 0.0



    def __init__(self):
        self.capture = VideoCaptureThreaded()
        self.mediapipe_engine = MediaPipeWrapper()

        self.show = VideoShowerThreaded(self.capture, self.mediapipe_engine)

        self.stopped = True
        self.results_hands = None

        self.showCameraWindow = False

        # This variable will contain relevant data for the left and right hands
        # There is a visible member, indicating if the hand in visible to the camera, at the moment
        # it also contains a few distances computed between landmarks
        self.handMeasures = {'Left': self.HandMeasures(),
                             'Right': self.HandMeasures()}

    def __del__(self):
        self.capture.stopped = True
        self.show.stopped = True

    def showFeed(self, state):
        self.showCameraWindow = state

    def showLandmarks(self, state):
        self.show.showLandMarks = state

    def euclidian(self, landmarkA, landmarkB):

        return math.sqrt((landmarkA.x - landmarkB.x) ** 2 +
                         (landmarkA.y - landmarkB.y) ** 2 +
                         (landmarkA.z - landmarkB.z) ** 2)

    def computeDistances_hand(self, hand):

        handMeasures = self.HandMeasures()

        handMeasures.dist_thumb_pointer = self.euclidian(hand.landmark[4], hand.landmark[8])
        handMeasures.dist_thumb_basepointer = self.euclidian(hand.landmark[4], hand.landmark[5])

        return handMeasures

    def start(self):

        self.capture.start()

        if self.showCameraWindow and self.show.stopped:
            self.show.start()

        if self.stopped:
            self.stopped = False
            Thread(target=self.compute, args=()).start()
        return self

    def compute(self):
        while not self.stopped and not self.capture.stopped:
            self.capture.image.flags.writeable = True
            self.results_hands = self.mediapipe_engine.detectHands(self.capture.image)
            self.results_face = self.mediapipe_engine.detectFaceMesh(self.capture.image)



            if self.results_hands.multi_hand_landmarks != None:
                for hand, handedness in zip(self.results_hands.multi_hand_landmarks, self.results_hands.multi_handedness):
                    self.handMeasures[handedness.classification[0].label] = self.computeDistances_hand(hand)
                    self.handMeasures[handedness.classification[0].label].visible = True
                    self.handMeasures[handedness.classification[0].label].hand = hand
                    #print(self.handMeasures['Left'].dist_thumb_basepointer)

            # test is showing camera feed window has been activated and start/stop the thread
            if self.showCameraWindow and self.show.stopped:
                    self.show.start()
            else:
                self.show.stop()

        self.stop()



    def stop(self):
        self.stopped = True

