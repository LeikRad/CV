import cv2
import mediapipe as mp
from dataclasses import dataclass
from dataclasses import field
import math

@dataclass
class HandMeasures:
    hand: list = field(default_factory=list)
    visible: bool = False
    dist_thumb_pointer: float = 0.0
    dist_thumb_basepointer: float = 0.0


handMeasures = {'Left': HandMeasures(),
                'Right': HandMeasures()}


def euclidian(landmarkA, landmarkB):
    return math.sqrt((landmarkA.x - landmarkB.x) ** 2 +
                     (landmarkA.y - landmarkB.y) ** 2 +
                     (landmarkA.z - landmarkB.z) ** 2)

def computeDistances_hand(hand):
    handMeasures = HandMeasures()

    handMeasures.dist_thumb_pointer = euclidian(hand.landmark[4], hand.landmark[8])
    handMeasures.dist_thumb_basepointer = euclidian(hand.landmark[4], hand.landmark[5])

    return handMeasures

def ProcessHandData(results_hands):
    """ Deal with discovering which hands are visible and computing some data for them """

    handMeasures['Left'].visible = handMeasures['Right'].visible = False

    if results_hands.multi_hand_landmarks != None:
        for hand, handedness in zip(results_hands.multi_hand_landmarks, results_hands.multi_handedness):
            handMeasures[handedness.classification[0].label] = computeDistances_hand(hand)
            handMeasures[handedness.classification[0].label].visible = True
            handMeasures[handedness.classification[0].label].hand = hand

    return handMeasures


mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_hands = mp.solutions.hands
mp_face_mesh = mp.solutions.face_mesh

drawing_spec = mp_drawing.DrawingSpec(thickness=1, circle_radius=1)

# For webcam input:
cap = cv2.VideoCapture(0)
with mp_hands.Hands(
    model_complexity=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.7) as hands:
    with mp_face_mesh.FaceMesh(
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5) as face_mesh:

      while cap.isOpened():
        success, image = cap.read()
        image = cv2.flip(image, 1)
        if not success:
          print("Ignoring empty camera frame.")
          # If loading a video, use 'break' instead of 'continue'.
          continue

        # To improve performance, optionally mark the image as not writeable to
        # pass by reference.
        image.flags.writeable = False
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results_hands = hands.process(image)

        results_face = face_mesh.process(image)

        ######################################
        # pre-processing some of the hand data just
        # to retrieve basic info about which
        # hands are visible and compute some extra

        # measures
        handMeasures = ProcessHandData(results_hands)

        #####################################
        # The left hand is visible
        if handMeasures['Left'].visible:
            customScale = handMeasures['Right'].dist_thumb_pointer * 1.2
            # do something with this value, here

        #####################################
        # The right hand is visible
        # if the Right hand is visible, use the wrist position to set the panda«s position
        # use the distance between thumb and pointer to move in the yy' direction
        # go to this link for landmark numbers: https://google.github.io/mediapipe/solutions/hands.html
        if handMeasures['Right'].visible:
            # position of the wrist for the right hand, over time
            print(handMeasures['Right'].hand.landmark[0].x,
                  handMeasures['Right'].hand.landmark[0].y,
                  handMeasures['Right'].hand.landmark[0].z)

        #####################################
        # Both hands are visible
        if handMeasures['Right'].visible and handMeasures['Left'].visible:
            # computing distance between the two pointer fingers
            dist_pointers = euclidian(handMeasures['Right'].hand.landmark[8],
                                      handMeasures['Left'].hand.landmark[8])


        ######################################
        # face landmarks
        if results_face.multi_face_landmarks != None:
            for face in results_face.multi_face_landmarks:
                print (face.landmark[0]) # mouth center
                print (face.landmark[2]) # nose tip



        ############################################
        # Draw the hand annotations on the image.
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        if results_hands.multi_hand_landmarks:
          for hand_landmarks in results_hands.multi_hand_landmarks:
            mp_drawing.draw_landmarks(
                image,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                mp_drawing_styles.get_default_hand_landmarks_style(),
                mp_drawing_styles.get_default_hand_connections_style())

        if results_face.multi_face_landmarks:
            for face_landmarks in results_face.multi_face_landmarks:
                # mp_drawing.draw_landmarks(
                #     image=image,
                #     landmark_list=face_landmarks,
                #     connections=mp_face_mesh.FACEMESH_TESSELATION,
                #     landmark_drawing_spec=None,
                #     connection_drawing_spec=mp_drawing_styles
                #         .get_default_face_mesh_tesselation_style())
                mp_drawing.draw_landmarks(
                    image=image,
                    landmark_list=face_landmarks,
                    connections=mp_face_mesh.FACEMESH_CONTOURS,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=mp_drawing_styles
                        .get_default_face_mesh_contours_style())
                mp_drawing.draw_landmarks(
                    image=image,
                    landmark_list=face_landmarks,
                    connections=mp_face_mesh.FACEMESH_IRISES,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=mp_drawing_styles
                        .get_default_face_mesh_iris_connections_style())


        # Flip the image horizontally for a selfie-view display.
        cv2.imshow('MediaPipe Hands', image)
        if cv2.waitKey(5) & 0xFF == 27:
          break
cap.release()