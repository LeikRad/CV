# 3D Fractal Engine

### Requirements
- Python 3.12

### Setup
1. (Opcional) Create a virtual environment
2. Install the requirements
```bash
pip install -r requirements.txt
```

### How to run
1. CD into ***src*** folder
2. Run the ***ui.py*** file to open the GUI
```bash
python ui.py
```
3. Run the ***main.py*** file to open the viewer
```bash
python main.py
```
4. Select the scene you want to render with the terminal running the viewer 

**Note:** *Add a Primitive* options in GUI only works for interative scene (Scene 3 - Interactive window)